CREATE USER yangbajing with NOSUPERUSER REPLICATION ENCRYPTED PASSWORD 'yangbajing';
\c template1;
CREATE EXTENSION adminpack;
CREATE EXTENSION hstore;
\c postgres;
CREATE DATABASE yangbajing OWNER=yangbajing TEMPLATE=template1;

